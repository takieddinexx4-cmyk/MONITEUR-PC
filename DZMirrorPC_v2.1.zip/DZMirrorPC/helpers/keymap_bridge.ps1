param(
  [Parameter(Mandatory = $true)][string]$WindowTitle,
  [Parameter(Mandatory = $true)][string]$ConfigPath
)

$ErrorActionPreference = 'SilentlyContinue'

$csharp = @"
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public class DZKeymapEngine {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }

    [StructLayout(LayoutKind.Sequential)]
    public struct MSLLHOOKSTRUCT {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT {
        public uint type;
        public MOUSEINPUT mi;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    // Windows 8+ Multi-Touch Injection structs
    public enum POINTER_INPUT_TYPE : uint {
        PT_POINTER = 1,
        PT_TOUCH = 2
    }

    [Flags]
    public enum POINTER_FLAGS : uint {
        NONE = 0x00000000,
        NEW = 0x00000001,
        INRANGE = 0x00000002,
        INCONTACT = 0x00000004,
        PRIMARY = 0x00002000,
        CONFIDENCE = 0x00004000,
        CANCELED = 0x00008000,
        DOWN = 0x00010000,
        UPDATE = 0x00020000,
        UP = 0x00040000
    }

    [Flags]
    public enum TOUCH_MASK : uint {
        NONE = 0x00000000,
        CONTACTAREA = 0x00000001,
        ORIENTATION = 0x00000002,
        PRESSURE = 0x00000004
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINTER_INFO {
        public POINTER_INPUT_TYPE pointerType;
        public uint pointerId;
        public uint frameId;
        public POINTER_FLAGS pointerFlags;
        public IntPtr sourceDevice;
        public IntPtr hwndTarget;
        public POINT ptPixelLocation;
        public POINT ptHimetricLocation;
        public POINT ptPixelLocationRaw;
        public POINT ptHimetricLocationRaw;
        public uint dwTime;
        public uint historyCount;
        public int InputData;
        public uint dwKeyStates;
        public ulong PerformanceCount;
        public int ButtonChangeType;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINTER_TOUCH_INFO {
        public POINTER_INFO pointerInfo;
        public uint touchFlags;
        public TOUCH_MASK touchMask;
        public RECT rcContact;
        public RECT rcContactRaw;
        public uint orientation;
        public uint pressure;
    }

    private const uint INPUT_MOUSE = 0;
    private const uint MOUSEEVENTF_MOVE = 0x0001;
    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;
    private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;

    private const int WH_KEYBOARD_LL = 13;
    private const int WH_MOUSE_LL = 14;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_KEYUP = 0x0101;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_SYSKEYUP = 0x0105;

    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_RBUTTONDOWN = 0x0204;
    private const int WM_RBUTTONUP = 0x0205;
    private const int WM_MBUTTONDOWN = 0x0207;
    private const int WM_MBUTTONUP = 0x0208;
    private const int WM_XBUTTONDOWN = 0x020B;
    private const int WM_XBUTTONUP = 0x020C;

    // Virtual codes for mouse buttons
    private const int VK_LMB = 0x01;
    private const int VK_RMB = 0x02;
    private const int VK_MMB = 0x04;
    private const int VK_X1  = 0x05;
    private const int VK_X2  = 0x06;

    private delegate IntPtr LowLevelProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

    [DllImport("user32.dll")]
    private static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern int GetSystemMetrics(int nIndex);

    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    private static extern bool ClipCursor(ref RECT lpRect);

    [DllImport("user32.dll")]
    private static extern bool ClipCursor(IntPtr lpRect);

    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [DllImport("user32.dll")]
    private static extern IntPtr SetProcessDpiAwarenessContext(IntPtr dpiFlag);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool InitializeTouchInjection(uint maxCount, uint dwMode);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool InjectTouchInput(uint count, POINTER_TOUCH_INFO[] contacts);

    private class TouchSlot {
        public uint Id;
        public int X;
        public int Y;
        public bool IsNew;
        public bool IsUp;
    }

    private static readonly object _stateLock = new object();
    private static IntPtr _kbHookId = IntPtr.Zero;
    private static IntPtr _msHookId = IntPtr.Zero;
    private static LowLevelProc _kbProc;
    private static LowLevelProc _msProc;

    private static string _targetTitle = "";
    private static string _configPath = "";
    private static DateTime _lastConfigWrite = DateTime.MinValue;
    private static IntPtr _targetHwnd = IntPtr.Zero;

    private static volatile bool _running = true;
    private static bool _enabled = true;
    private static bool _editMode = false;
    private static List<Dictionary<string, object>> _buttons = new List<Dictionary<string, object>>();
    private static HashSet<int> _pressedVks = new HashSet<int>();

    private static int _lastX = -1, _lastY = -1, _lastW = -1, _lastH = -1;
    private static bool _lastVisible = false;

    // Touch engine state
    private static bool _touchSupported = false;
    private static Dictionary<uint, TouchSlot> _slots = new Dictionary<uint, TouchSlot>();

    // Joystick smooth state
    private static bool _joyActive = false;
    private static double _joyCurX = 0, _joyCurY = 0;

    // Mouse Aim state
    private static bool _aimMode = false;
    private static bool _aimTouchDown = false;
    private static double _aimCurX = 0, _aimCurY = 0;
    private static long _aimLastMoveMs = 0;
    private static int _aimPendingDx = 0, _aimPendingDy = 0;
    private static bool _cursorClipped = false;

    // Button slot mapping (key -> pointerId 2..9)
    private static Dictionary<string, uint> _btnSlotIds = new Dictionary<string, uint>();
    private static uint _nextBtnSlot = 2;

    // Fallback single-mouse state
    private static bool _fallbackJoyDown = false;

    private static void EnableDpiAwareness() {
        try {
            // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4
            SetProcessDpiAwarenessContext(new IntPtr(-4));
        } catch {
            try { SetProcessDPIAware(); } catch { }
        }
    }

    public static void Start(string title, string configPath) {
        EnableDpiAwareness();
        _targetTitle = title;
        _configPath = configPath;
        LoadConfig();

        try {
            // 0x3 = TOUCH_FEEDBACK_NONE
            _touchSupported = InitializeTouchInjection(10, 0x3);
        } catch {
            _touchSupported = false;
        }
        Console.WriteLine("TOUCH_MODE:" + (_touchSupported ? "MULTITOUCH" : "MOUSE_FALLBACK"));
        Console.Out.Flush();

        _kbProc = KbHookCallback;
        _msProc = MsHookCallback;
        using (Process curProcess = Process.GetCurrentProcess())
        using (ProcessModule curModule = curProcess.MainModule) {
            IntPtr hMod = GetModuleHandle(curModule.ModuleName);
            _kbHookId = SetWindowsHookEx(WH_KEYBOARD_LL, _kbProc, hMod, 0);
            _msHookId = SetWindowsHookEx(WH_MOUSE_LL, _msProc, hMod, 0);
        }

        // High-frequency 120Hz worker thread for smooth joystick + mouse aim + multi-touch
        Thread worker = new Thread(WorkerLoop);
        worker.IsBackground = true;
        worker.Start();

        // UI thread timer for config reload & window bounds tracking (50ms)
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        timer.Interval = 50;
        timer.Tick += (s, e) => {
            LoadConfig();
            TrackWindow();
        };
        timer.Start();

        Application.Run();
        _running = false;
        ReleaseCursorClip();
        if (_kbHookId != IntPtr.Zero) UnhookWindowsHookEx(_kbHookId);
        if (_msHookId != IntPtr.Zero) UnhookWindowsHookEx(_msHookId);
    }

    private static void LoadConfig() {
        try {
            if (!File.Exists(_configPath)) return;
            DateTime wt = File.GetLastWriteTimeUtc(_configPath);
            if (wt == _lastConfigWrite) return;
            _lastConfigWrite = wt;
            string json = File.ReadAllText(_configPath, Encoding.UTF8);
            var ser = new JavaScriptSerializer();
            var obj = ser.Deserialize<Dictionary<string, object>>(json);
            if (obj == null) return;
            lock (_stateLock) {
                if (obj.ContainsKey("enabled")) _enabled = Convert.ToBoolean(obj["enabled"]);
                if (obj.ContainsKey("editMode")) _editMode = Convert.ToBoolean(obj["editMode"]);
                if (obj.ContainsKey("buttons") && obj["buttons"] is System.Collections.ArrayList arr) {
                    var list = new List<Dictionary<string, object>>();
                    foreach (var item in arr) {
                        if (item is Dictionary<string, object> d) list.Add(d);
                    }
                    _buttons = list;
                }
                if (!_enabled || _editMode) {
                    DisengageAllLocked();
                }
            }
        } catch { }
    }

    private static void TrackWindow() {
        if (_targetHwnd == IntPtr.Zero || !IsWindow(_targetHwnd)) {
            _targetHwnd = FindWindow(null, _targetTitle);
        }
        if (_targetHwnd == IntPtr.Zero || !IsWindow(_targetHwnd) || IsIconic(_targetHwnd)) {
            if (_lastVisible) {
                _lastVisible = false;
                lock (_stateLock) { DisengageAllLocked(); }
                Console.WriteLine("BOUNDS:0,0,0,0,0");
                Console.Out.Flush();
            }
            return;
        }
        RECT rc;
        if (!GetClientRect(_targetHwnd, out rc)) return;
        POINT pt = new POINT { X = 0, Y = 0 };
        ClientToScreen(_targetHwnd, ref pt);
        int w = rc.Right - rc.Left;
        int h = rc.Bottom - rc.Top;
        if (w <= 10 || h <= 10) return;

        bool fgMatch = (GetForegroundWindow() == _targetHwnd);
        if (!fgMatch) {
            lock (_stateLock) {
                if (_pressedVks.Count > 0 || _aimMode || _joyActive || _aimTouchDown) {
                    DisengageAllLocked();
                }
            }
        }

        if (!_lastVisible || pt.X != _lastX || pt.Y != _lastY || w != _lastW || h != _lastH) {
            _lastVisible = true;
            _lastX = pt.X; _lastY = pt.Y; _lastW = w; _lastH = h;
            Console.WriteLine("BOUNDS:1," + pt.X + "," + pt.Y + "," + w + "," + h);
            Console.Out.Flush();
        }
    }

    private static void ReleaseCursorClip() {
        if (_cursorClipped) {
            _cursorClipped = false;
            try { ClipCursor(IntPtr.Zero); } catch { }
        }
    }

    private static void EnsureCursorClipped() {
        if (!_lastVisible || _lastW <= 20 || _lastH <= 20) return;
        RECT clip = new RECT {
            Left = _lastX + 4,
            Top = _lastY + 4,
            Right = _lastX + _lastW - 4,
            Bottom = _lastY + _lastH - 4
        };
        try {
            ClipCursor(ref clip);
            _cursorClipped = true;
        } catch { }
    }

    private static void DisengageAllLocked() {
        _pressedVks.Clear();
        if (_aimMode) {
            _aimMode = false;
            Console.WriteLine("AIM:0");
            Console.Out.Flush();
        }
        _aimPendingDx = 0;
        _aimPendingDy = 0;
        ReleaseCursorClip();

        if (_touchSupported) {
            foreach (var kv in _slots) {
                kv.Value.IsUp = true;
                kv.Value.IsNew = false;
            }
            if (_slots.Count > 0) FlushTouchFrameLocked();
        } else if (_fallbackJoyDown) {
            _fallbackJoyDown = false;
            SendMouseFallback(_lastX + _lastW / 2, _lastY + _lastH / 2, MOUSEEVENTF_LEFTUP);
        }
        _joyActive = false;
        _aimTouchDown = false;
    }

    private static int KeyNameToVk(string key) {
        if (string.IsNullOrEmpty(key)) return 0;
        key = key.Trim().ToUpperInvariant();
        if (key.Length == 1) {
            char c = key[0];
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return (int)c;
            if (c == '~' || c == '`') return 0xC0;
            if (c == '-') return 0xBD;
            if (c == '=') return 0xBB;
            if (c == '[') return 0xDB;
            if (c == ']') return 0xDD;
            if (c == ';') return 0xBA;
            if (c == '\'') return 0xDE;
            if (c == ',') return 0xBC;
            if (c == '.') return 0xBE;
            if (c == '/') return 0xBF;
        }
        switch (key) {
            case "LMB": case "MOUSE1": return VK_LMB;
            case "RMB": case "MOUSE2": return VK_RMB;
            case "MMB": case "MOUSE3": return VK_MMB;
            case "X1": case "MOUSE4": return VK_X1;
            case "X2": case "MOUSE5": return VK_X2;
            case "TILDE": case "BACKQUOTE": case "OEM_3": return 0xC0;
            case "SPACE": return 0x20;
            case "ENTER": return 0x0D;
            case "TAB": return 0x09;
            case "ESC": case "ESCAPE": return 0x1B;
            case "CAPSLOCK": case "CAPS": return 0x14;
            case "SHIFT": case "LSHIFT": return 0xA0;
            case "RSHIFT": return 0xA1;
            case "CTRL": case "CONTROL": case "LCTRL": return 0xA2;
            case "RCTRL": return 0xA3;
            case "ALT": case "LALT": return 0xA4;
            case "RALT": return 0xA5;
            case "BACKSPACE": return 0x08;
            case "UP": case "ARROWUP": return 0x26;
            case "DOWN": case "ARROWDOWN": return 0x28;
            case "LEFT": case "ARROWLEFT": return 0x25;
            case "RIGHT": case "ARROWRIGHT": return 0x27;
            case "F1": return 0x70; case "F2": return 0x71; case "F3": return 0x72; case "F4": return 0x73;
            case "F5": return 0x74; case "F6": return 0x75; case "F7": return 0x76; case "F8": return 0x77;
            case "F9": return 0x78; case "F10": return 0x79; case "F11": return 0x7A; case "F12": return 0x7B;
            default: return 0;
        }
    }

    private static uint GetSlotForButton(string id) {
        if (string.IsNullOrEmpty(id)) id = "_default";
        uint slot;
        if (_btnSlotIds.TryGetValue(id, out slot)) return slot;
        slot = _nextBtnSlot;
        _nextBtnSlot++;
        if (_nextBtnSlot > 9) _nextBtnSlot = 2;
        _btnSlotIds[id] = slot;
        return slot;
    }

    private static void SetTouchSlotLocked(uint id, int x, int y, bool down) {
        if (!_touchSupported) return;
        TouchSlot slot;
        if (down) {
            if (_slots.TryGetValue(id, out slot)) {
                slot.X = x;
                slot.Y = y;
                slot.IsUp = false;
            } else {
                _slots[id] = new TouchSlot { Id = id, X = x, Y = y, IsNew = true, IsUp = false };
            }
        } else {
            if (_slots.TryGetValue(id, out slot)) {
                slot.IsUp = true;
                slot.IsNew = false;
            }
        }
    }

    private static void FlushTouchFrameLocked() {
        if (!_touchSupported || _slots.Count == 0) return;
        int count = _slots.Count;
        POINTER_TOUCH_INFO[] contacts = new POINTER_TOUCH_INFO[count];
        List<uint> toRemove = new List<uint>();
        int idx = 0;

        foreach (var kv in _slots) {
            TouchSlot s = kv.Value;
            POINTER_TOUCH_INFO info = new POINTER_TOUCH_INFO();
            info.pointerInfo.pointerType = POINTER_INPUT_TYPE.PT_TOUCH;
            info.pointerInfo.pointerId = s.Id;
            info.pointerInfo.hwndTarget = IntPtr.Zero;
            info.pointerInfo.ptPixelLocation = new POINT { X = s.X, Y = s.Y };

            if (s.IsUp) {
                info.pointerInfo.pointerFlags = POINTER_FLAGS.UP;
                toRemove.Add(kv.Key);
            } else if (s.IsNew) {
                info.pointerInfo.pointerFlags = POINTER_FLAGS.DOWN | POINTER_FLAGS.INRANGE | POINTER_FLAGS.INCONTACT | POINTER_FLAGS.CONFIDENCE;
                s.IsNew = false;
            } else {
                info.pointerInfo.pointerFlags = POINTER_FLAGS.UPDATE | POINTER_FLAGS.INRANGE | POINTER_FLAGS.INCONTACT | POINTER_FLAGS.CONFIDENCE;
            }

            info.touchMask = TOUCH_MASK.CONTACTAREA | TOUCH_MASK.ORIENTATION | TOUCH_MASK.PRESSURE;
            info.rcContact = new RECT { Left = s.X - 2, Top = s.Y - 2, Right = s.X + 2, Bottom = s.Y + 2 };
            info.orientation = 90;
            info.pressure = 512;
            contacts[idx++] = info;
        }

        InjectTouchInput((uint)count, contacts);
        foreach (uint k in toRemove) _slots.Remove(k);
    }

    private static void SendMouseFallback(int screenX, int screenY, uint flags) {
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        if (sw <= 0 || sh <= 0) return;
        int absX = (int)Math.Round((double)screenX * 65535.0 / (sw - 1));
        int absY = (int)Math.Round((double)screenY * 65535.0 / (sh - 1));
        INPUT[] inp = new INPUT[1];
        inp[0].type = INPUT_MOUSE;
        inp[0].mi.dx = absX;
        inp[0].mi.dy = absY;
        inp[0].mi.dwFlags = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE | flags;
        SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
    }

    private static void WorkerLoop() {
        Stopwatch sw = Stopwatch.StartNew();
        while (_running) {
            long nowMs = sw.ElapsedMilliseconds;
            lock (_stateLock) {
                if (_enabled && !_editMode && _lastVisible && _targetHwnd != IntPtr.Zero && GetForegroundWindow() == _targetHwnd) {
                    bool dirty = false;

                    // 1. Smooth Interpolated WASD Joystick (slot 0)
                    Dictionary<string, object> joy = null;
                    Dictionary<string, object> aim = null;
                    foreach (var b in _buttons) {
                        string t = b.ContainsKey("type") ? Convert.ToString(b["type"]) : "";
                        if (t == "joystick" && joy == null) joy = b;
                        else if (t == "aim" && aim == null) aim = b;
                    }

                    if (joy != null) {
                        int vkUp = KeyNameToVk(joy.ContainsKey("up") ? Convert.ToString(joy["up"]) : "W");
                        int vkDown = KeyNameToVk(joy.ContainsKey("down") ? Convert.ToString(joy["down"]) : "S");
                        int vkLeft = KeyNameToVk(joy.ContainsKey("left") ? Convert.ToString(joy["left"]) : "A");
                        int vkRight = KeyNameToVk(joy.ContainsKey("right") ? Convert.ToString(joy["right"]) : "D");

                        int dx = 0, dy = 0;
                        if (_pressedVks.Contains(vkLeft)) dx -= 1;
                        if (_pressedVks.Contains(vkRight)) dx += 1;
                        if (_pressedVks.Contains(vkUp)) dy -= 1;
                        if (_pressedVks.Contains(vkDown)) dy += 1;

                        double cx = _lastX + (Convert.ToDouble(joy["x"]) / 100.0) * _lastW;
                        double cy = _lastY + (Convert.ToDouble(joy["y"]) / 100.0) * _lastH;
                        double radPct = joy.ContainsKey("radius") ? Convert.ToDouble(joy["radius"]) : 11.0;
                        double rad = (radPct / 100.0) * Math.Min(_lastW, _lastH);

                        if (dx == 0 && dy == 0) {
                            if (_joyActive) {
                                _joyActive = false;
                                if (_touchSupported) {
                                    SetTouchSlotLocked(0, (int)Math.Round(_joyCurX), (int)Math.Round(_joyCurY), false);
                                    dirty = true;
                                } else if (_fallbackJoyDown) {
                                    _fallbackJoyDown = false;
                                    SendMouseFallback((int)cx, (int)cy, MOUSEEVENTF_LEFTUP);
                                }
                                Console.WriteLine("KEY:JOY:0");
                                Console.Out.Flush();
                            }
                        } else {
                            double len = Math.Sqrt(dx * dx + dy * dy);
                            double targetX = cx + (dx / len) * rad;
                            double targetY = cy + (dy / len) * rad;

                            if (!_joyActive) {
                                _joyActive = true;
                                _joyCurX = cx;
                                _joyCurY = cy;
                                if (_touchSupported) {
                                    SetTouchSlotLocked(0, (int)Math.Round(cx), (int)Math.Round(cy), true);
                                    dirty = true;
                                } else {
                                    _fallbackJoyDown = true;
                                    SendMouseFallback((int)cx, (int)cy, MOUSEEVENTF_LEFTDOWN);
                                }
                                Console.WriteLine("KEY:JOY:1");
                                Console.Out.Flush();
                            } else {
                                // Smooth exponential easing towards target angle/radius (buttery smooth)
                                _joyCurX += (targetX - _joyCurX) * 0.42;
                                _joyCurY += (targetY - _joyCurY) * 0.42;
                                if (_touchSupported) {
                                    SetTouchSlotLocked(0, (int)Math.Round(_joyCurX), (int)Math.Round(_joyCurY), true);
                                    dirty = true;
                                } else {
                                    SendMouseFallback((int)Math.Round(_joyCurX), (int)Math.Round(_joyCurY), 0);
                                }
                            }
                        }
                    }

                    // 2. Smooth Mouse Aim / Camera Look (slot 1)
                    if (_aimMode && aim != null && _touchSupported) {
                        double ax = _lastX + (Convert.ToDouble(aim["x"]) / 100.0) * _lastW;
                        double ay = _lastY + (Convert.ToDouble(aim["y"]) / 100.0) * _lastH;
                        double sens = aim.ContainsKey("sensitivity") ? Convert.ToDouble(aim["sensitivity"]) : 1.0;
                        double rangePct = aim.ContainsKey("range") ? Convert.ToDouble(aim["range"]) : 20.0;
                        double maxRx = (rangePct / 100.0) * _lastW;
                        double maxRy = (rangePct / 100.0) * _lastH;

                        int mdx = _aimPendingDx;
                        int mdy = _aimPendingDy;
                        _aimPendingDx = 0;
                        _aimPendingDy = 0;

                        if (mdx != 0 || mdy != 0) {
                            _aimLastMoveMs = nowMs;
                            if (!_aimTouchDown) {
                                _aimTouchDown = true;
                                _aimCurX = ax;
                                _aimCurY = ay;
                                SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), true);
                                dirty = true;
                            } else {
                                double nextX = _aimCurX + mdx * sens;
                                double nextY = _aimCurY + mdy * sens;

                                // If reaching aim boundary, lift and re-center for infinite 360 rotation
                                if (Math.Abs(nextX - ax) > maxRx || Math.Abs(nextY - ay) > maxRy) {
                                    SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), false);
                                    FlushTouchFrameLocked();
                                    _aimCurX = ax;
                                    _aimCurY = ay;
                                    SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), true);
                                    FlushTouchFrameLocked();
                                    _aimCurX = ax + Math.Max(-maxRx * 0.5, Math.Min(maxRx * 0.5, mdx * sens));
                                    _aimCurY = ay + Math.Max(-maxRy * 0.5, Math.Min(maxRy * 0.5, mdy * sens));
                                } else {
                                    _aimCurX = nextX;
                                    _aimCurY = nextY;
                                }
                                SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), true);
                                dirty = true;
                            }
                        } else if (_aimTouchDown && (nowMs - _aimLastMoveMs > 220)) {
                            // Idle auto-reset so finger is ready at center
                            _aimTouchDown = false;
                            SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), false);
                            dirty = true;
                        }
                    } else if (_aimTouchDown) {
                        _aimTouchDown = false;
                        SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), false);
                        dirty = true;
                    }

                    if (_touchSupported && (dirty || _slots.Count > 0)) {
                        FlushTouchFrameLocked();
                    }
                }
            }
            Thread.Sleep(8);
        }
    }

    private static bool HandleButtonVkLocked(int vk, bool isDown, bool isUp) {
        if (vk == 0) return false;
        // Check joystick keys
        foreach (var b in _buttons) {
            if (b.ContainsKey("type") && Convert.ToString(b["type"]) == "joystick") {
                int u = KeyNameToVk(b.ContainsKey("up") ? Convert.ToString(b["up"]) : "W");
                int d = KeyNameToVk(b.ContainsKey("down") ? Convert.ToString(b["down"]) : "S");
                int l = KeyNameToVk(b.ContainsKey("left") ? Convert.ToString(b["left"]) : "A");
                int r = KeyNameToVk(b.ContainsKey("right") ? Convert.ToString(b["right"]) : "D");
                if (vk == u || vk == d || vk == l || vk == r) {
                    if (isDown) _pressedVks.Add(vk);
                    if (isUp) _pressedVks.Remove(vk);
                    return true;
                }
            }
        }

        // Check tap / hold buttons
        bool matched = false;
        foreach (var b in _buttons) {
            string t = b.ContainsKey("type") ? Convert.ToString(b["type"]) : "tap";
            if (t == "joystick" || t == "aim") continue;
            int bvk = KeyNameToVk(b.ContainsKey("key") ? Convert.ToString(b["key"]) : "");
            if (bvk == 0 || bvk != vk) continue;

            string id = b.ContainsKey("id") ? Convert.ToString(b["id"]) : "";
            int px = (int)Math.Round(_lastX + (Convert.ToDouble(b["x"]) / 100.0) * _lastW);
            int py = (int)Math.Round(_lastY + (Convert.ToDouble(b["y"]) / 100.0) * _lastH);

            if (isDown && !_pressedVks.Contains(vk)) {
                _pressedVks.Add(vk);
                if (_touchSupported) {
                    uint slot = GetSlotForButton(id);
                    SetTouchSlotLocked(slot, px, py, true);
                    FlushTouchFrameLocked();
                } else {
                    SendMouseFallback(px, py, MOUSEEVENTF_LEFTDOWN);
                }
                Console.WriteLine("KEY:" + id + ":1");
                Console.Out.Flush();
                matched = true;
            } else if (isUp && _pressedVks.Contains(vk)) {
                _pressedVks.Remove(vk);
                if (_touchSupported) {
                    uint slot = GetSlotForButton(id);
                    SetTouchSlotLocked(slot, px, py, false);
                    FlushTouchFrameLocked();
                } else {
                    SendMouseFallback(px, py, MOUSEEVENTF_LEFTUP);
                }
                Console.WriteLine("KEY:" + id + ":0");
                Console.Out.Flush();
                matched = true;
            } else if (isDown) {
                matched = true;
            }
        }
        return matched;
    }

    private static IntPtr KbHookCallback(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0) {
            int msg = wParam.ToInt32();
            int vk = Marshal.ReadInt32(lParam);
            bool isDown = (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN);
            bool isUp = (msg == WM_KEYUP || msg == WM_SYSKEYUP);

            if (isDown && vk == 0x78) { // F9 toggles overlay visibility
                Console.WriteLine("TOGGLE_VIS");
                Console.Out.Flush();
            }

            if (_enabled && !_editMode && _lastVisible && _targetHwnd != IntPtr.Zero && GetForegroundWindow() == _targetHwnd) {
                lock (_stateLock) {
                    // Check Aim toggle key (e.g. ~ / OEM_3 or ALT)
                    foreach (var b in _buttons) {
                        if (b.ContainsKey("type") && Convert.ToString(b["type"]) == "aim") {
                            int toggleVk = KeyNameToVk(b.ContainsKey("key") ? Convert.ToString(b["key"]) : "~");
                            if (toggleVk != 0 && vk == toggleVk && isDown) {
                                _aimMode = !_aimMode;
                                if (_aimMode) {
                                    EnsureCursorClipped();
                                    int cx = _lastX + _lastW / 2;
                                    int cy = _lastY + _lastH / 2;
                                    SetCursorPos(cx, cy);
                                } else {
                                    ReleaseCursorClip();
                                    if (_aimTouchDown) {
                                        _aimTouchDown = false;
                                        SetTouchSlotLocked(1, (int)Math.Round(_aimCurX), (int)Math.Round(_aimCurY), false);
                                        FlushTouchFrameLocked();
                                    }
                                }
                                Console.WriteLine("AIM:" + (_aimMode ? "1" : "0"));
                                Console.Out.Flush();
                                return (IntPtr)1;
                            }
                        }
                    }

                    if (HandleButtonVkLocked(vk, isDown, isUp)) {
                        return (IntPtr)1;
                    }
                }
            }
        }
        return CallNextHookEx(_kbHookId, nCode, wParam, lParam);
    }

    private static IntPtr MsHookCallback(int nCode, IntPtr wParam, IntPtr lParam) {
        if (nCode >= 0 && _enabled && !_editMode && _lastVisible && _targetHwnd != IntPtr.Zero && GetForegroundWindow() == _targetHwnd) {
            int msg = wParam.ToInt32();
            MSLLHOOKSTRUCT ms = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));

            // Ignore injected synthetic mouse events from fallback mode
            if ((ms.flags & 0x01) != 0) {
                return CallNextHookEx(_msHookId, nCode, wParam, lParam);
            }

            lock (_stateLock) {
                if (_aimMode) {
                    if (msg == WM_MOUSEMOVE) {
                        int cx = _lastX + _lastW / 2;
                        int cy = _lastY + _lastH / 2;
                        int dx = ms.pt.X - cx;
                        int dy = ms.pt.Y - cy;
                        if (dx != 0 || dy != 0) {
                            _aimPendingDx += dx;
                            _aimPendingDy += dy;
                            SetCursorPos(cx, cy);
                        }
                        return (IntPtr)1;
                    }
                    if (msg == WM_LBUTTONDOWN) { if (HandleButtonVkLocked(VK_LMB, true, false)) return (IntPtr)1; }
                    if (msg == WM_LBUTTONUP)   { if (HandleButtonVkLocked(VK_LMB, false, true)) return (IntPtr)1; }
                    if (msg == WM_RBUTTONDOWN) { if (HandleButtonVkLocked(VK_RMB, true, false)) return (IntPtr)1; }
                    if (msg == WM_RBUTTONUP)   { if (HandleButtonVkLocked(VK_RMB, false, true)) return (IntPtr)1; }
                }

                // Middle click & side mouse buttons work even without Aim Mode if bound
                if (msg == WM_MBUTTONDOWN) {
                    // If an aim button is bound to MMB, toggle aim mode
                    foreach (var b in _buttons) {
                        if (b.ContainsKey("type") && Convert.ToString(b["type"]) == "aim" && KeyNameToVk(Convert.ToString(b["key"])) == VK_MMB) {
                            _aimMode = !_aimMode;
                            if (_aimMode) {
                                EnsureCursorClipped();
                                SetCursorPos(_lastX + _lastW / 2, _lastY + _lastH / 2);
                            } else {
                                ReleaseCursorClip();
                            }
                            Console.WriteLine("AIM:" + (_aimMode ? "1" : "0"));
                            Console.Out.Flush();
                            return (IntPtr)1;
                        }
                    }
                    if (HandleButtonVkLocked(VK_MMB, true, false)) return (IntPtr)1;
                }
                if (msg == WM_MBUTTONUP) { if (HandleButtonVkLocked(VK_MMB, false, true)) return (IntPtr)1; }
                if (msg == WM_XBUTTONDOWN || msg == WM_XBUTTONUP) {
                    int xbtn = (int)((ms.mouseData >> 16) & 0xFFFF);
                    int xvk = (xbtn == 1) ? VK_X1 : VK_X2;
                    bool down = (msg == WM_XBUTTONDOWN);
                    if (HandleButtonVkLocked(xvk, down, !down)) return (IntPtr)1;
                }
            }
        }
        return CallNextHookEx(_msHookId, nCode, wParam, lParam);
    }
}
"@

Add-Type -TypeDefinition $csharp -ReferencedAssemblies System.Windows.Forms, System.Web.Extensions
[DZKeymapEngine]::Start($WindowTitle, $ConfigPath)
